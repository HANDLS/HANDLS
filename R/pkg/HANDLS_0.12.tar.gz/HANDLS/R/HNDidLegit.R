HNDidLegit = function(dat, auth=w00Dem, by.auth='HNDid', by.dat='HNDid') {

	if	(!is.data.frame(auth)) {
		auth = as.data.frame(auth)
		names(auth) = by.auth
		auth$chk.HNDidIlleg = 1
		}

	mrg = merge(auth, dat, by.x=by.auth, by.y=by.dat)

	mrg[,names(dat)]
	}
