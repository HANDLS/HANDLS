HNDtagNeupsy = function() {

	c(	'OK',
		'?Literacy',
		'?Psychiatric',
		'?Education',
		'?Illness',
		'?Language',
		'?Misunderstood',
		'?Impaired',
		'?Quit',
		'?Other',
		'Literacy',
		'Psychiatric',
		'Education',
		'Illness',
		'Language',
		'Misunderstood',
		'Impaired',
		'Quit',
		'Other')

}

