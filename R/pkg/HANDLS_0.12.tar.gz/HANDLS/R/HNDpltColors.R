HNDpltColors = function() {

	colors = list()

	colorSexW = rgb(237,  28,  36, maxColorValue=255)
	colorSexM = rgb( 46,  49, 146, maxColorValue=255)
	colorRacB = rgb(247, 148,  30, maxColorValue=255)
	colorRacW = rgb(  0, 148,  68, maxColorValue=255)
	colorPovB = rgb(216, 200,   0, maxColorValue=255)
	colorPovA = rgb(102,  45, 145, maxColorValue=255)

	colors$Sex	= c(colorSexW, colorSexM)
	colors$Race	= c(colorRacW, colorRacB)
	colors$Poverty	= c(colorPovA, colorPovB)
	colors$Age7	= zQ(gray90, gray80, gray70, gray60, gray50, gray40, gray30)
	colors$Age2	= zQ(gray80, gray40)
	colors$YesNo	= zQ(purple, orange)

	names(colors$Sex) = zQ(Women, Men)
	names(colors$Race)	= zQ(White, AfrAm)
	names(colors$Poverty)	= zQ(Above, Below)
	names(colors$Age7)	= c('30-34', '35-39', '40-44', '45-49', '50-54', '55-59', '60-64')
	names(colors$Age2)	= zQ(belowMedian, aboveMedian)
	names(colors$YesNo)	= zQ(No, Yes)

	colors
	}
