HNDfixIDrange = function(dat) {

	dat = with(dat, dat[HNDid<8030000000 | HNDid>8229999999, 'HNDid']) = NA
	return(dat)
	}
