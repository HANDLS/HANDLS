HNDload = function(dFrame='', rdata='', Quiet=FALSE) {

	if	(rdata=='') {
		library(RMySQL)
		HNDdb = dbConnect(MySQL(), group='HND')
		locInfo = dbGetQuery(HNDdb, paste0("select * from HNDdataDocTst.dFrames where dFrame='", dFrame, "'"))

		if	(locInfo$url!='') {
			fnm = locInfo$url
			obj = load(url(locInfo$url))
			}
		else	{
			fnm = locInfo$fnm
			if (!file.exists(fnm)) stop(paste('No such file: ', fnm))
			obj = load(fnm)
			}
		}
	else	{
		fnm = paste0('/prj/hnd/zrdata/', rdata, '.rdata')
		if (!file.exists(fnm)) stop(paste('No such file: ', fnm))
		obj = load(fnm)
		}

	dir <- ls()

	if	(!Quiet) message(paste0(obj, ' loaded from ', fnm))

	eval(parse(text = paste0('return(', obj, ')')))
	}
