HNDdataDoc = function(dat, dfn='') {

	if (dfn=='') dfn = deparse(substitute(dat))
	lbl = data.frame()
	val = data.frame()
	fac = data.frame()

	for	(j in 1:ncol(dat)) {
		lbl[j,'dFrame'] = dfn
		lbl[j,'varNme'] = names(dat)[j]
		lbl[j,'Class1']	= class(dat[,j])[1]
		lbl[j,'Class2']	= class(dat[,j])[2]
		lbl[j,'Mode']	= mode(dat[,j])
		lbl[j,'nLevel']	= nlevels(dat[,j])
		lbl[j,'datSeq']	= j
		lbl[j,'varLbl'] = label(dat[,j])

		if	(is.factor(dat[,j])) {
			tmp = data.frame()

			for	(k in 1:nlevels(dat[,j])) {
				tmp[k,'dFrame'] = dfn
				tmp[k,'varNme'] = names(dat)[j]
				tmp[k,'value']	= k
				tmp[k,'label']	= levels(dat[,j])[k]
				}

			val = rbind(val, tmp)
			}
			else {
			lbl[j,'vldMin']	= as.character(min(dat[,j], na.rm=T))
			lbl[j,'vldMax']	= as.character(max(dat[,j], na.rm=T))
			}

		if	(is.factor(dat[,j])) {
			vnam = names(dat)[j]
			nlev = nlevels(dat[,j])
			stmt = paste0('DF$', vnam, ' = factor(DF$', vnam, ',levels=1:', nlev, ', labels=c(')
			stmt = paste0(stmt, "'", levels(dat[,j])[1], "'")

			for	(k in 2:nlev) {
				stmt = paste0(stmt, ",'", levels(dat[,j])[k], "'")
				}

			fac = rbind(fac, as.data.frame(paste0(stmt, '))')))
			}


		}

	if (nrow(val)>0) names(fac) = 'Statement'

	lbl = lbl[,zQ(dFrame,datSeq,varNme,nLevel,Class1,Class2,Mode,vldMin,vldMax,varLbl)]

	return(list(vars=lbl,vals=val,stmt=fac))
	}
