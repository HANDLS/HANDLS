HNDdataTbl = function(dat) {

	dfn.nam = deparse(substitute(dat))
	dfn.dat = HNDdataDoc(dat, dfn.nam)

	print(dfn.nam)
	print(dfn.dat)

	library(RMySQL)

	dbHNDdataDoc = dbConnect(MySQL(), group='HNDdataDocR')

	dbWriteTable(dbHNDdataDoc, 'varNames', dfn.dat$vars, row.names=F, overwrite=F, append=T)

	if (nrow(dfn.dat$vals)>0) dbWriteTable(dbHNDdataDoc, 'fmtNames', dfn.dat$vals, row.names=F, overwrite=F, append=T)
	}
