zBySummary = function(dat, formula, digits=5.2, format='f') {

	library(doBy)
	tbl = summaryBy(formula, data=dat, FUN=zByFUN)
	nc  = ncol(tbl)

	for	(j in (nc-3):nc) {
		tbl[,j] = zFormat(tbl[,j], digits, format)
		}

	return(tbl)
	}
