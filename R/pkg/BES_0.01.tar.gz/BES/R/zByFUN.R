zByFUN <- function(x, ...) {

	c(	n    = length(x[!is.na(x)]),
		mean = mean  (x, na.rm=TRUE),
		sd   = sd    (x, na.rm=TRUE),
		min  = min   (x, na.rm=TRUE),
		max  = max   (x, na.rm=TRUE)
		)
	}
