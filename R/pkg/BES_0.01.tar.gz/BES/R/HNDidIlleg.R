HNDidIlleg = function(dat, auth=w00Dem, by.auth='HNDid', by.dat='HNDid') {

	auth$chk.HNDidIlleg = 1

	mrg = merge(auth, dat, by.x=by.auth, by.y=by.dat, all.y=T)

	mrg[is.na(mrg$chk.HNDidIlleg),names(dat)]
	}
