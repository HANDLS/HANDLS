zMixHat = function(dat, mer, derivCov="", fixedCov="", otherCov="", vary="", CI=FALSE) {

	pre <- eval(parse(text = paste("expand.grid(", vary, ")")))
	eval(parse(text = paste("pre$", terms(mer)[[2]], "=0", sep="")))

	if	(derivCov[1] != "")

		for	(cov in derivCov) {
			eval(parse(text = paste("pre$", sub("=", "=pre$", cov), sep="")))
			}

	if	(fixedCov[1] != "")

		for	(cov in fixedCov) {
			eval(parse(text = paste("if ( is.factor(dat$", cov, ")) pre$", cov, "=mean(as.numeric(dat$", cov, "), na.rm=T)-1", sep="")))
			eval(parse(text = paste("if (!is.factor(dat$", cov, ")) pre$", cov, "=mean(as.numeric(dat$", cov, "), na.rm=T)",   sep="")))
			}

	if	(otherCov[1] != "")

		for	(cov in otherCov) {
			eval(parse(text = paste("pre$", cov)))
			}

	mtx <- model.matrix(terms(mer), pre)
	hat <- mtx %*% fixef(mer)

	if	(CI) {
		# pvar = diag(mtx %*% tcrossprod(vcov(mer), mtx))
		pvar = diag(mtx %*% (as.matrix(vcov(mer)) %*% t(mtx)))
		tvar = pvar + VarCorr(mer)[[1]][1]
		CIlo = hat - 2 * sqrt(pvar)
		CIup = hat + 2 * sqrt(pvar)
		cbind(pre, hat, CIlo, CIup)
		}
	else
		cbind(pre, hat)
	}
