HNDdupsDelete = function(dat) {

	dups = HNDdupsFind(dat)
	nRow = nrow(dups)

	if	(nRow > 0) {
		xRow = vector()
		preID = 0

		for	(i in 1:nRow) {

			if	(preID != dups[i,'HNDid']) {
				preID = dups[i,'HNDid']
				}
			else	xRow = c(xRow, rownames(dups[i,]))
			}

		dat = dat[-as.integer(xRow),]
		}

	dat[order(dat$HNDid),]
	}
