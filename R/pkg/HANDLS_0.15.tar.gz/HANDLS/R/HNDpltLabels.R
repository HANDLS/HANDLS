HNDpltLabels = function() {

	labels = list()

	labels$Sex	= zQ(Women, Men)
	labels$Race	= zQ(White, AfrAm)
	labels$Poverty	= c("At or above poverty cut-off", "Below poverty cut-off")
	labels$Age7	= c("30-34", "35-39", "40-44", "45-49", "50-54", "55-59", "60-64")
	labels$Age2	= c("Below median age", "Above median age")
	labels$Educ	= c("<=HS", "postHS")
	labels$YesNo	= zQ(No, Yes)

	labels
	}
