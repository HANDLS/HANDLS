HNDdupsFind = function(dat) {

	dups = dat[dat$HNDid %in% dat[duplicated(dat$HNDid),'HNDid'],]
	dups[order(dups$HNDid),]
	}

