HNDdupsPrint = function(dups) {

	nRow  = nrow(dups)

	if	(nRow > 0) {
		grp = data.frame()
		preID = 0

		for	(i in 1:nRow) {

			if	(preID != dups[i,'HNDid']) {

				if	(nrow(grp) > 0) {
					cat('\n')
					print(grp)
					}

				preID = dups[i,'HNDid']
				grp = dups[i,]
				}

			else {	grp = rbind(grp, dups[i,])
				}
			}

		cat('\n')
		print(grp)
		}
	}
