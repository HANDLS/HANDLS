HNDid <- function(str) {

	gsub('[^[:digit:]]', '', str)
# 	gsub('[^\\d]', '', str, perl=T)
	}
