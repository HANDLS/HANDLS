HNDload = function(fnm='w00Demographics') {

	fnm = paste0('/prj/hnd/zrdata/', fnm, '.rdata');
	if (!file.exists(fnm)) stop(paste('No such file: ', fnm))
	dnm = load(fnm)
	eval(parse(text=dnm))
	}
