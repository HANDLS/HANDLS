HNDdashID = function(HNDid) {

	HNDid = paste0(substr(HNDid,1,3), '-', substr(HNDid,4,8), '-', substr(HNDid,9,10))
	}
