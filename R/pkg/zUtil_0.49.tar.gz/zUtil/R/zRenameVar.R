zRenameVar = function(dat, oldName, newName) {

	names(dat)[names(dat)==oldName] = newName
	dat
	}
