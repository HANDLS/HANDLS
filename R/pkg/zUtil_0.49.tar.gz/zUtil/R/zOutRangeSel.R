zOutRangeSel = function(dat, valLo, valUp, varNames, valRep=NA) {

	for	(j in zNamesLoc(dat, varNames)) {
		dat[!is.na(dat[,j]) & (dat[,j]<valLo | dat[,j]>valUp),j] = valRep
		}

	return(dat)
	}
