zGet1st <- function(dat, vars, ID='id', REPEAT='visit', nrepeat=1, NREPEAT='nrepeat', SQL=FALSE) {

	options(sqldf.driver = "SQLite")		# as per FAQ #7 force SQLite
	options(gsubfn.engine = "R")			# as per FAQ #5 use R code rather than tcltk

	library(RMySQL)
	library(sqldf)

	sql <- paste('select v1.', ID, ',v1.', REPEAT, ',count(*) ', NREPEAT, sep='')

	for	(k in 1:length(vars)) {
		sql = paste(sql, ', v1.', vars[k], sep='')
		}

	sql <- paste(sql, ' from dat v1 join dat v2 on v1.', ID, '=v2.', ID, ' and v1.', REPEAT, '>=v2.', REPEAT, ' group by v1.', ID, ',v1.', REPEAT, ' having count(*) <=', nrepeat, ' order by v1.', ID, ',v1.', REPEAT, sep='')

	if (SQL) print(sql)

	dat <- sqldf(sql)
	}
