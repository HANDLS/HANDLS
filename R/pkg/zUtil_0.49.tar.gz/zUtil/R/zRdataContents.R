zRdataContents <- function(fileName) {

	load(fileName)
	contents <- ls()
	xx <- grepl("fileName", contents)
	print(contents[!xx])
	}
