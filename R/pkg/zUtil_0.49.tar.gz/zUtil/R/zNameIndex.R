zNameIndex = function(dat, varName) {
	return(which(names(dat) == varName))
	}
