zLatticeRegline <- function(x, y) {

	panel.grid(h=-1, v=2)
	panel.xyplot(x, y)
	panel.lmline(x, y)
	}
