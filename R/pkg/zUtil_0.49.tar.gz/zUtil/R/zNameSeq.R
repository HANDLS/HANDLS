zNameSeq <- function(base, seq, ndigits=0) {

	if (ndigits==0) ndigits <- as.integer(log10(max(seq))) + 1

	sprintf(paste("%s%0", ndigits, "d", sep=""), base, seq)
	}
