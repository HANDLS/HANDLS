zQuick = function(dat, nQuick=4, nHead=5) {
	if (nQuick>0) print(dim(dat))
	if (nQuick>1) print(str(dat, list.len=1000000))
	if (nQuick>2) print(head(dat, n=nHead))
	if (nQuick>3) print(summary(dat))
	}
