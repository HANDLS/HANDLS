zOutRange = function(dat, valLo, valUp, valRep=NA) {

	dat[dat<valLo | dat>valUp] = valRep

	return(dat)
	}
