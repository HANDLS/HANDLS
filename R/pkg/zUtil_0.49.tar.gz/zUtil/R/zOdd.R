zOdd = function(n) {

	n = as.integer(n) %% 2 != 0
	return(n)
	}
