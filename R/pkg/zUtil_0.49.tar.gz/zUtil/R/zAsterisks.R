zAsterisks = function(p) {

	zAsterisk <- function(p) {

		if	(p < .001) zAsterisk <- "***"
		else if	(p < .01)  zAsterisk <- "** "
		else if	(p < .05)  zAsterisk <- "*  "
		else	           zAsterisk <- "   "

		}

	if	(is.vector(p)) {
		tbl = vector()

		for	(j in 1:length(p)){
			tbl[j] = zAsterisk(p[j])
			}

		return(tbl)
		}

	else	return(zAsterisk(p))
	}
