zNamesLoc = function(dat, varNames) {
	return(which(names(dat) %in% varNames))
	}
