zSQL <- function(dat, sql) {

	options(sqldf.driver = "SQLite")		# as per FAQ #7 force SQLite
	options(gsubfn.engine = "R")			# as per FAQ #5 use R code rather than tcltk

	library(RMySQL)
	library(sqldf)

	dat <- sqldf(sql)
	}
