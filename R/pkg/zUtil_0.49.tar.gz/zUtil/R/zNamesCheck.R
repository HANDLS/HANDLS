zNamesCheck <- function(dat, selectVars) {

	nam <- names(dat)
	sel <- sub('^', '\\^', selectVars)
	sel <- sub('$', '\\$', sel)

	for	(k in 1:length(sel)) {

		if (!any(grepl(sel[k], nam))) {
			cat("Can't find", selectVars[k])
			chk = grep(selectVars[k], nam, ignore.case=TRUE)

			if	(length(chk)>0) {
				cat(" -- try:")

				for	(j in 1:length(chk)) {
					cat(' ', nam[chk[j]], ";", sep='')
					}
				}

			cat("\n")
			}

		}
	}
