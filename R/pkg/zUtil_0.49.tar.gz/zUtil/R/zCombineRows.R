zCombineRows = function(dat, IDnme='HNDid') {

	dnm = vector()
	dups = which(duplicated(dat[,IDnme]))
	nC = ncol(dat)

	for	(k in 1:length(dups)) {
		tmp = dat[dat[,IDnme]==dat[dups[k],IDnme],]
		dnm = c(dnm, as.numeric(rownames(tmp)[1:(nrow(tmp)-1)]))
		nR = nrow(tmp)

		for	(j in 1:(nR-1)) {
			for (i in 1:nC) if (is.na(tmp[nR,i])) tmp[nR,i] = tmp[j,i]
			}

		dat[dups[k],] = tmp[nR,]
		}

	dat[-dnm,]
	}
