zGetLast <- function(dat, vars, ID='id', REPEAT='visit', SQL=FALSE) {

	options(sqldf.driver = "SQLite")		# as per FAQ #7 force SQLite
	options(gsubfn.engine = "R")			# as per FAQ #5 use R code rather than tcltk

	library(RMySQL)
	library(sqldf)

	sql <- paste('select ', ID, ',', REPEAT, ',', sep='')

	for	(k in 1:length(vars)) {
		sql <- paste(sql, vars[k], sep='')
		}


	sql <- paste(sql, ' from (select * from dat order by ', ID, ' desc) as x group by ', ID, sep='')

	if (SQL) print(sql)

	dat <- sqldf(sql)
	}
