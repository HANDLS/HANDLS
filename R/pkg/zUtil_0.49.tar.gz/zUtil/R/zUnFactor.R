zUnFactor = function(dat) {

	dat = as.numeric(as.character(dat))
	}
