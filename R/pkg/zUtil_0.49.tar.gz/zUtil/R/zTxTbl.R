zTxTbl <- function(tbl, txLabel="", txCaption="", txCapLoc="top", txFontsize="small", txNewpage=FALSE, txPlace='htbp', txFile="") {

	library(xtable, quietly=TRUE, warn.conflicts=FALSE)

	if (txNewpage) cat('\\clearpage\n')
	tex = print(xtable(tbl, label=txLabel, caption=txCaption), caption.placement=txCapLoc, size=txFontsize, table.placement=txPlace)

	if (txFile != "") write (tex, txFile)
	}

