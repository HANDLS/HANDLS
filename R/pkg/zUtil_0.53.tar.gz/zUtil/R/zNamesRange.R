zNamesRange = function(dat, varBeg, varEnd) {
	nBeg = which(names(dat)==varBeg)
	nEnd = which(names(dat)==varEnd)

	if	(length(nBeg)==0 | length(nEnd)==0) stop('one or both name(s) not found')

	else return(nBeg:nEnd)

	}
