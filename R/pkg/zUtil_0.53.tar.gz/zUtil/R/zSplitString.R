zSplitString <- function(str, delim=',') {

	str <- strsplit(str, split=delim, fixed=T)
	mtx <- matrix(unlist(str))
	vec <- as.vector(mtx[,1])
	vec <- sub("[[:blank:]]+$", "", vec)
	vec <- sub("^[[:blank:]]+", "", vec)
	return(vec)
	}
