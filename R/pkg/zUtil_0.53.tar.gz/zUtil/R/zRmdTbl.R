zRmdTbl = function(tbl, htm=TRUE, htmLabel='', htmCaption = "", htmDigits = 2, htmFile = "", htmFontsize=8, htmTranspose=FALSE) {

	htmBlank = function(chr) {

		if (gsub('\\s', '', chr) == '') chr = '&nbsp;'
		return(chr)
		}

	htmColHead = function() {						#***Column headings...

		cat(append=T, file=htmFile, sep='', '<tr><th>&nbsp;</th>')

		for	(j in 1:nCol) {
			if	(nDim==1)	str = htmBlank(' ')
			else			str = htmBlank(colnames(tbl)[j])
			cat(append=T, file=htmFile, sep='', '<th ', tblR, str, '</th>')
			}

		cat(append=T, file=htmFile, sep='', '</tr>')
		}


	if	(htm) {
		tblC = paste0('class="tblC0', htmFontsize, 'sans">')
		tblL = paste0('class="tblL0', htmFontsize, 'sans">')
		tblR = paste0('class="tblR0', htmFontsize, 'sans">')

#		if (htmTranspose) tbl = zTblAstT(tbl)

		cat(file=htmFile, sep='', '<p class=tblCaption>', htmCaption, '</p>')
		cat(append=T, file=htmFile, sep='', '<table>')

		nDim = length(attributes(tbl)$dimnames)
		nRow = nrow(tbl)

		if	(nDim==1)	nCol = 1
		else			nCol = ncol(tbl)

		if	(nDim==1) {
			htmColHead()

			for	(i in 1:nRow) {
				str = htmBlank(rownames(tbl)[i])
				cat(append=T, file=htmFile, sep='', '<tr><td ', tblL, str, '</td>')

				str = htmBlank(format(tbl[i], digits=htmDigits))
				str = gsub('\\*', '&#42;', str)
				cat(append=T, file=htmFile, sep='', '<td ', tblR, str, '</td>')

				cat(append=T, file=htmFile, sep='', '</tr>')
				}
			}

		else if	(nDim==2) {
			htmColHead()

			for	(i in 1:nRow) {
				str = htmBlank(rownames(tbl)[i])
				cat(append=T, file=htmFile, sep='', '<tr><td ', tblL, str, '</td>')

				for	(j in 1:nCol) {
					str = htmBlank(format(tbl[i,j], digits=htmDigits))
					str = gsub('\\*', '&#42;', str)
					cat(append=T, file=htmFile, sep='', '<td ', tblR, str, '</td>')
					}

				cat(append=T, file=htmFile, sep='', '</tr>')
				}
			}

		else if (nDim==3) {

			for	(k in 1:length(attributes(tbl)$dimnames[[3]])) {
				str = htmBlank('')
				cat(append=T, file=htmFile, sep='', '<tr><th ', tblL, str, '</th>')
				str = htmBlank(attributes(tbl3)$dimnames[[3]][[k]])
				cat(append=T, file=htmFile, sep='', '<th colspan="', nCol, '" ', tblC, str, '</th></tr>')

				htmColHead()

				for	(i in 1:nRow) {
					str = htmBlank(rownames(tbl)[i])
					cat(append=T, file=htmFile, sep='', '<tr><td ', tblL, str, '</td>')

					for	(j in 1:nCol) {
						str = htmBlank(format(tbl[i,j,k], digits=htmDigits))
						str = gsub('\\*', '&#42;', str)
						cat(append=T, file=htmFile, sep='', '<td ', tblR, str, '</td>')
						}

					cat(append=T, file=htmFile, sep='', '</tr>')
					}
				}
			}

		cat(append=T, file=htmFile, sep='', '</table>')
		}

	else	print(tbl)
	}
