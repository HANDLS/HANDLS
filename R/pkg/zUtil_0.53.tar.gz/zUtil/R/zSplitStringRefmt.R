zSplitStringRefmt = function(dat, varID, varSplit, chrSplit, colNames) {

	datList = strsplit(dat[,varSplit], chrSplit)

	nRow = nrow(dat)
	nCol = length(datList[[1]])

	mtx = matrix(nrow=nRow, ncol=nCol+1)

	for	(j in 1:nRow) {
		mtx[j,] = c(dat[j,varID], datList[[j]])
		}

	colnames(mtx) = c(varID, colNames)

	return(as.data.frame(mtx, stringsAsFactors=F))
	}
