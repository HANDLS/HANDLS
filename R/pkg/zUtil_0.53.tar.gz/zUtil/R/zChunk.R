zChunk = function(chunkLength, chunkStart=1, chunkBy=10) {

	chunkCuts = ceiling((chunkLength - chunkStart + 1) / chunkBy)
	chunks    = vector('list', chunkCuts)
	cBeg      = chunkStart

	for	(k in 1:chunkCuts) {
		cEnd = cBeg + chunkBy - 1
		chunks[[k]] = cBeg:min(cEnd,chunkLength)
		cBeg = cEnd + 1
		}

	chunks
	}
