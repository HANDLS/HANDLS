zFormulaString <- function(formula) {

	chr <- as.character(formula)
	paste(chr[2], chr[1], chr[3])
	}
