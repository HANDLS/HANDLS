zCountNAbyRow <- function (dat) {
	apply(dat, 1, zCountNA)
	}
