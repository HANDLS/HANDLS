zXtendFrame <- function(dat, byVar, fnm, selectVars='') {

	if	(length(byVar) > 1) {
		byX = zSplitString(byVar[1], ',')
		byY = zSplitString(byVar[2], ',')
		}
		else {
		byX = zSplitString(byVar[1], ',')
		byY = byX
		}

	if	(is.data.frame(fnm))
		mrg = fnm

	else {

		if	(grepl("\\.dta$",   fnm, ignore.case=TRUE)) mrg <- stata.get(fnm)

		if	(grepl("\\.sav$",   fnm, ignore.case=TRUE)) mrg <- spss.get(fnm)

		if	(grepl("\\.rdata$", fnm, ignore.case=TRUE)) {
			dfn <- load(fnm)
			eval(parse(text = paste("mrg = ", dfn[1])))
			}
		}

	if	(selectVars[1] == '') selectVars <- names(mrg)

	for	(j in 1:length(byY)) {
		if (!any(grepl(byY[j], selectVars))) selectVars = c(byY, selectVars)
		}

	dat <- merge(dat, mrg[,selectVars], by.x=byX, by.y=byY, all.x=TRUE)

	return(dat)
	}
