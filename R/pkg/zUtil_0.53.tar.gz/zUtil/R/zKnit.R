zKnit = function(dnmFigures, dnmCache, asisWidth=200, cache=FALSE, defaultHeight=4, defaultWidth=4, echo=FALSE) {

# 	opts_knit$set(aliases=c(h='fig.height', w='fig.width', cap='fig.cap', scap='fig.scap', path='fig.path'))
# 	opts_knit$set(eval.before = c('fig.cap','fig.scap'))
# 	opts_chunk$set(cache=cache, comment=NA, w=defaultWidth, h=defaultHeight)
# 	opts_chunk$set(dev=c('png','pdf'), echo=F, size='small', message=F, warning=F)
# 	opts_chunk$set(fig.path=dnmFigures)
# 	opts_chunk$set(cache.path=dnmCache)
# 	options(width=asisWidth)

	opts_knit$set(	aliases		= c(h='fig.height', w='fig.width', cap='fig.cap', scap='fig.scap', path='fig.path'),
			eval.before	= c('fig.cap','fig.scap')
			)

	opts_chunk$set(	cache		= cache,
			comment		= NA,
			w		= defaultWidth,
			h		= defaultHeight,
			dev		= c('png','pdf'),
			echo		= echo,
			size		= 'small',
			message		= F,
			warning		= F,
			fig.path	= dnmFigures,
			cache.path	= dnmCache
			)

	options(width=asisWidth)

	numFig = local({
		nFig = 0

		function(cap) {
			nFig <<- nFig + 1
			paste0('Figure ', nFig, '. ', cap)
			}
		})

	knit_hooks$set(cap = function(before, options, environ) {
			if (before) paste0("<figure><figcaption>", numFig(options$fig.cap), "</figcaption></figure>")
			})
	}
