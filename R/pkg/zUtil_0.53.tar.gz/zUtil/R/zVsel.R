zVsel = function(dat, ...) {

	idx = vector(mode='integer')
	lst = as.list(sys.call())

	for	(k in 3:length(lst)) {
		lst[[k]] = as.character(lst[[k]])

		if	(lst[[k]][1]==':') {
			rng = which(names(dat)==lst[[k]][2]):which(names(dat)==lst[[k]][3])
			}
		else	rng = which(names(dat)==lst[[k]])

		idx = c(idx, rng)
		}

	idx
	dat[,idx]
	}
