zUnique <- function(dat, idVars) {

	return(dat[-which(duplicated(dat[,idVars])),])
	}
