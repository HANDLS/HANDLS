zTblAstT <- function(tbl) {

	nVars <- nrow(tbl)
	nEffs <- ncol(tbl) / 2

	sEffs <- seq(1, ncol(tbl), 2)

	k <- 0
	Effs <- as.vector('')
	Vars <- rownames(tbl)

	for	(j in sEffs) {
		k <- k + 1
		Effs[k] <- colnames(tbl)[j]
		}

	m <- 0
	res <- data.frame(check.names=FALSE)

	for	(j in sEffs) {
		k <- 0
		m <- m + 1

		for	(i in 1:nVars) {
			k <- k + 1
			tmp <- data.frame()
			tmp[1,1] <- tbl[i,j]
			tmp[1,2] <- tbl[i,j+1]
			colnames(tmp) <- c(rownames(tbl)[i], as.character(i))

			if (k==1)	row = tmp
			else		row = cbind(row, tmp)
			}

		rownames(row) <- Effs[m]
		res <- rbind(res, row)
		}

	for	(j in seq(2, 2*nVars, 2)) colnames(res)[j] <- ' '

	return(res)
	}