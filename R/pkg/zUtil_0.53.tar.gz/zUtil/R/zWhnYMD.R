zWhnYMD = function(yy, mm, dd, base=2000) {

	yy = as.integer(yy)

	yy = ifelse (yy >= 100, yy, yy + base)

	paste0(zFormat(yy, 4), '-', zFormat(as.numeric(mm), 2, z=T), '-', zFormat(as.numeric(dd), 2, z=T))
	}
