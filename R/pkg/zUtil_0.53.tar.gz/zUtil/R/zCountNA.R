zCountNA <- function(dat) {
	sum(is.na(dat))
	}
