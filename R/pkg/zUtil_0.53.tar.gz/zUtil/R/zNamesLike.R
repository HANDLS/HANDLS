zNamesLike <- function(dat, str, order=FALSE) {

	if	(order)
		zNames(dat[grep(str, zNames(dat), ignore.case=TRUE)])
		else
		names(dat[grep(str, names(dat), ignore.case=TRUE)])

	}
