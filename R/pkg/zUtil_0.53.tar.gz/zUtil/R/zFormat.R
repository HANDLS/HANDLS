zFormat = function(x, digits=5.2, format='f', zero=FALSE, auto=-1) {

	if (auto >= 0) digits = ifelse (auto==0, zWidth(x), zWidth(x) + auto + 1 + auto / 10)

	if (digits %% as.integer(digits) == 0) digits = paste0(digits, '.0')

	if (zero) percent = '%0'
	else percent = '%'

	fmt = sprintf(paste0(percent, digits, format), x)
	return(fmt)
	}
