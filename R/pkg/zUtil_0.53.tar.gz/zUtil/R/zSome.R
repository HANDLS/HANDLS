zSome <- function(x, ...) UseMethod("zSome")

# adapted from head() and tail() by John Fox in car package

zSome.default <- function(x, n=10, ...){
    len <- length(x)
    ans <- x[sort(sample(len, min(n, len)))]
    if (length(dim(x)) == 1)
        array(ans, n, list(names(ans)))
    else ans
    }

zSome.matrix <- function(x, n=10, ...){
  nr <- nrow(x)
  x[sort(sample(nr, min(n, nr))), , drop = FALSE]
  }

zSome.data.frame <- function(x, n=10, ...){
    nr <- nrow(x)
    x[sort(sample(nr, min(n, nr))), , drop=FALSE]
    }
