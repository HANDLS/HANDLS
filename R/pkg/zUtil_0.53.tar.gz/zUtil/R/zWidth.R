zWidth = function(x) {

	if	(x != 0) {
		width = as.integer(log10(abs(x))) + 1
		if (x < 0) width = width + 1
		}
	else	{
		width = 1
		}

	width
	}
