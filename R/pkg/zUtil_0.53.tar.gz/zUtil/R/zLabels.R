zLabels = function(dat, display=TRUE) {

	lbl = data.frame(name=names(dat), varLabel=label(dat), stringsAsFactors=F)

	if	(display) {
		mC = max(nchar(lbl[,1]))

		for	(k in 1:nrow(lbl))
			cat(lbl[k,1], ': ', rep(' ', mC-nchar(lbl[k,1])+1), lbl[k,2], '\n', sep='')

		}

	else
	return(lbl)
	}
