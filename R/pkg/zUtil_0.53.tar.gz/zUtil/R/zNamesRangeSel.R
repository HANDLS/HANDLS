zNamesRangeSel = function(dat, varBeg, varEnd) {

	nBeg = which(names(dat)==varBeg)
	nEnd = which(names(dat)==varEnd)

	if	(length(nBeg)==0 | length(nEnd)==0) {
		if (length(nBeg)==0) message(varBeg, ' not found')
		if (length(nEnd)==0) message(varEnd, ' not found')
		stop('One or both name(s) not found')
		}

	else return(names(dat)[nBeg:nEnd])

	}
