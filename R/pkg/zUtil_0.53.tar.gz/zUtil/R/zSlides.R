zSlides = function(fnm='index.Rmd') {

	library(slidify)
	library(tools)

	bnm = file_path_sans_ext(fnm)
	bnm = basename(bnm)
	dnm = dirname(bnm)
	old = setwd(dnm)
	htm = paste0(dnm, '/', bnm, '.htm')

	slidify(fnm, htm)

	setwd(old)
	htm
	}
