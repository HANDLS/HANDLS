zBetw = function(val, lo, hi) {

	val >= lo & val <= hi
	}
