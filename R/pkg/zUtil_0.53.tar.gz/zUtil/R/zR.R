zR = function(dat, sel, FUN, ..., skip=F) {

	lbl = label(dat)

	if	(skip)
		dat = FUN(dat, ...)
	else
		dat[!is.na(dat) & sel] = FUN(dat[!is.na(dat) & sel])

	label(dat) = lbl
	return(dat)
	}
