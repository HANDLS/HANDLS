zMissingDigits = function(dat, nD, offset=4) {

	idx = which(dat>=10^nD-offset)

	if (length(idx)>0) dat[idx] = NA

	dat
	}
