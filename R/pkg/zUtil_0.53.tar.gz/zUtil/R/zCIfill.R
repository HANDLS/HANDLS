zCIfill <- function(x, y, yLo, yUp, newPlot=FALSE, ...) {

	if	(newPlot) plot (x, y, type="n", ...)

	tGray <- rgb(204, 204, 204, 125, maxColorValue=255)

	for	(j in 2:length(x)) {
		polyX <- c(  x[j-1],   x[j-1],   x[j],   x[j])
		polyY <- c(yUp[j-1], yLo[j-1], yLo[j], yUp[j])
		polygon(polyX, polyY, border=FALSE, col=tGray)
		}

	lines(x, y, type="l", ...)
	}
