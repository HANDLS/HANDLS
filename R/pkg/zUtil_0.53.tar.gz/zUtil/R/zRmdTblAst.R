zRmdTblAst = function(tbl, htmLabel='', htmCaption = "", htmDigits = 2, htmFile = "", htmFontsize=8, htmTranspose=FALSE) {

	htmBlank = function(chr) {

		if (gsub('\\s', '', chr) == '') chr = '&nbsp;'
		return(chr)
		}

	tblC = paste0('class="tblC0', htmFontsize, 'sans">')
	tblL = paste0('class="tblL0', htmFontsize, 'sans">')
	tblR = paste0('class="tblR0', htmFontsize, 'sans">')

	if (htmTranspose) tbl = zTblAstT(tbl)

	cat(file=htmFile, sep='', '<p class=tblCaption>', htmCaption, '</p>')
	cat(append=T, file=htmFile, sep='', '<table border=0 cellpadding=3 cellspacing=0>')

	nCol = ncol(tbl)
	nRow = nrow(tbl)

# ***Column headings...

	cat(append=T, file=htmFile, sep='', '<tr><th>&nbsp;</th>')

	for	(j in 1:nCol) {
		str = htmBlank(names(tbl)[j])
		cat(append=T, file=htmFile, sep='', '<th ', tblR, str, '</th>')
		}

	cat(append=T, file=htmFile, sep='', '</tr>')

# ***Body...

	for	(i in 1:nRow) {
		str = htmBlank(rownames(tbl)[i])
		cat(append=T, file=htmFile, sep='', '<tr><td ', tblL, str, '</td>')

		for	(j in 1:nCol) {
			str = htmBlank(format(tbl[i,j], digits=htmDigits))
			str = gsub('\\*', '&#42;', str)
			cat(append=T, file=htmFile, sep='', '<td ', tblL, str, '</td>')
			}

		cat(append=T, file=htmFile, sep='', '</tr>')
		}

	cat(append=T, file=htmFile, sep='', '</table>')
	}
