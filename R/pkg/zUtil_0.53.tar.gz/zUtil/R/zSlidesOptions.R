zSlidesOptions = function(asisWidth=200, defaultHeight=4, defaultWidth=4) {

	opts_knit$set(aliases = c(h = "fig.height", w = "fig.width"))
	opts_chunk$set(comment=NA, w=defaultWidth, h=defaultHeight)
	}
