zDuplicate <- function (dat) {
	duplicate <- ifelse(c(0, a$col[-length(a$col)])==a$col, 1, 0)
	}
