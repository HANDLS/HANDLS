zHTM <- function(tbl, htmCaption='', htmCapLoc='top', htmFile='') {
	library(xtable)

	htm = print(xtable(tbl,caption=htmCaption), caption.placement=htmCapLoc, type='html', file=htmFile)
	invisible(htm)
	}
