tst=matrix(nrow=3,ncol=3)
tst[1,1] = '11'
tst[2,2] = '22'
print.char.matrix(tst,top.border=F, left.border=F,hsep=' ')
write(tst, file="", append=T)
tst
as.data.frame(tst)
tst = matrix(c('.11*','.09'), nrow=3, ncol=2)
tst
colnames(tst) = zQ(column1,column2)
rownames(tst) = zQ(row1,column2,column3)
r
print(zAsterisks(.000))

r=zStatCor(as.matrix(dxa[,varX]), as.matrix(dxa[,varY]))

rstar = function(r) {

	p <- matrix(2*(1-pt(abs(r$r)*sqrt(r$n-2)/sqrt(1-r$r*r$r), r$n-2)), nrow=nr, ncol=nc)

	nc = ncol(r$r)
	nr = nrow(r$r)
	mtx = matrix(nrow=nrow(r$r), ncol=ncol(r$r))

	for	(i in 1:nr) {
	for	(j in 1:nc) {
		# mtx[i,j] = rbind(r$r[i,j], zAsterisks(p[i,j]))
		mtx[i,j] = paste(formatC(r$r[i,j], digits=2, format='f', width=5), zAsterisks(p[i,j]), sep='')
		}}
}

as.data.frame(mtx)

formatC(r$r[1,3], digits=2, format='f', width=5)