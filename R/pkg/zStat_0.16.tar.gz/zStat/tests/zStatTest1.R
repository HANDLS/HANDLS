zStatAdd <- function(x1, x2) {

	n = length(x1)
	x <- .C('zstattest1', as.double(x1), as.double(x2), x3=double(n), as.integer(n), NAOK=T, PACKAGE="zStat")
#	x = x$x3
	return(x$x3)
	}
