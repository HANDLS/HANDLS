library(zStat)
dxa = stata.get("/prj/hnd/zdta/dxa.dta")
varX = zQ(DXAlegsRegFat,DXAtrunkBMD,DXAtrunkRval,DXAtrunkTiss)
varY = zQ(DXAtotalTisFat,DXAtotalRegFat,DXAspineL1BMD)
rcorr(as.matrix(dxa[,varX]), as.matrix(dxa[,varY]))
zStatCor(dxa[,varX], dxa[,varY])

