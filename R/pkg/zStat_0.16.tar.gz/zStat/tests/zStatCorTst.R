zStatCorTst <- function(x, y) {

	z.x <- as.matrix(x)
#	z.x[is.na(z.x)] <- 1e30
        m.x <- is.na(x)

	if	(missing(y)) {
		sym <- TRUE
		z.y <- z.x
		m.y <- m.x
		}
	else	{
		sym <- FALSE
		z.y <- as.matrix(y)
#		z.y[is.na(z.y)] <- 1e30
		m.y = is.na(y)
		}

	ns  <- as.integer(nrow(z.x))
	nvx <- as.integer(ncol(z.x))
	nvy <- as.integer(ncol(z.y))

	if (ns != nrow(z.y)) stop ("zStatCor: x and y must have same number of rows")

	storage.mode(z.x) <- "double"
	storage.mode(z.y) <- "double"

	mtx <- .Fortran("zStatCorTst1", as.double(z.x), as.double(z.y), as.logical(m.x), as.logical(m.y), r=double(nvx*nvy), n=double(nvx*nvy), ns, nvx, nvy, NAOK=TRUE, PACKAGE="zStat")

	xNames = colnames(z.x)
	yNames = colnames(z.y)

	r = matrix(mtx$r, nrow=nvx, ncol=nvy)
	n = matrix(mtx$n, nrow=nvx, ncol=nvy)

	dimnames(r) = list(xNames, yNames)
	dimnames(n) = list(xNames, yNames)

	structure(list(r=r, n=n), class="zCor")
	}
