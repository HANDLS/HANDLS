/* #include <Arith.h> */
#include <math.h>
#include <R.h>

/*
void zstattest1(double *a[], double *b[], double *c[], int *n) {
*/
void zstattest1(double *a, double *b, double *c, int *n) {

	int i;

	for	(i = 0; i < *n; i++) {
/*
		*c[i] = *a[i] + *b[i];
*/
		if	(R_FINITE(a[i]) && R_FINITE(b[i]))
		c[i] = a[i] + b[i];
		else
		c[i] = NA_REAL;
		}

/*
return R_FINITE(*x);
*/
	}