# ndx(i,j,m) (j * m + i)

ndx = function(i, j, m) {
	j * m + i
	}

ndx(1,1,3)
ndx(0,0,3)
ndx(2,2,3)
ndx(0,1,3)
ndx(2,0,3)

for	(j in 0:2) {
for (i in 0:2) {
	print(ndx(i,j,3))
}
}