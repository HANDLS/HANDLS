/* #include <Arith.h> */
#include <math.h>
#include <R.h>

int zstatfinite(double *x) {


/*
#include <R_ext/R.h>

R_exts/Arith.h included by R.h
*/

return R_FINITE(*x);
	}