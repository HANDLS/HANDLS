zStatAdd <- function(x1, x2) {

	n = length(x1)
	x <- .Fortran('zstatadd', x1, x2, x3=double(n), n, PACKAGE="zStat")
#	x = x$x3
	return(x$x3)
	}
