zReg = function(dvnames, iform, dat, tex = FALSE, astTranspose=FALSE, ...) {

	nReg = 0

	for	(y in dvnames) {
		nReg = nReg + 1
		f = paste(y, "~", iform, sep="")
#		mod = lm(as.formula(f), data=dat, na.action=na.omit)
		eval(parse(text = paste("mod = lm(", f, ", data = dat, na.action = na.omit)", sep = "")))
		sum = summary(mod)
		row = data.frame(Rsq=sum$r.squared, ast=zAsterisks(pf(sum$fstatistic[1], sum$fstatistic[2], sum$fstatistic[3], lower.tail=FALSE)))
		rownames(row) = y

		for (j in 2:length(rownames(sum$coefficients))) {
			res = data.frame(sum$coefficients[j,1], zAsterisks(sum$coefficients[j,4]))
			row = cbind(row, res)
			}

		if	(nReg == 1) {
			tbl = row
			}
			else
			tbl = rbind(tbl, row)

		}

	n = 2
	tbl.colnames = zQ(Rsq, " ")

	for (j in 2:length(rownames(sum$coefficients))) {
		n = n + 1
		tbl.colnames[n] = rownames(sum$coefficients)[j]
		n = n + 1
		tbl.colnames[n] = " "
		}

	colnames(tbl) = tbl.colnames

	if (astTranspose) tbl <- zTblAstT(tbl)

	if (tex) zTxTbl(tbl, ...)
	else     tbl
	}
