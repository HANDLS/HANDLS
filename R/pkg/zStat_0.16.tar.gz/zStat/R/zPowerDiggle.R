zPowerDiggle = function(effSize=.5, alpha=.05, power=.8, tails=2, nRepeat=2, rho=.6) {

# Diggle et al (2002) longitudinal power -- number per group

	zAlpha = -qnorm(alpha / tails)
	zBeta  = qnorm(power)
	nPerGrp = (2 * (zAlpha + zBeta)**2 * (1 + (nRepeat - 1) * rho)) / (nRepeat * effSize**2)
	as.integer(nPerGrp)
	}
