zLogisticReg = function(formula, dat, tex=FALSE, ...) {

#	logReg = glm(formula, data=dat, family=binomial, na.action=na.omit)
	eval(parse(text = paste("logReg = glm(", zFormulaString(formula), ", data=dat, family=binomial, na.action=na.omit)", sep = "")))
	odds = exp(coef(logReg))
	conf = exp(confint(logReg))
	summ = summary(logReg)
	coef = summ$coefficients
	asts = zAsterisks(coef[1,4])

	for	(i in 2:logReg$rank) {
		asts[i] = zAsterisks(coef[i,4])
		}

	tabl = as.data.frame(coef)
	tabl = as.data.frame(cbind(tabl, odds, conf, asts))

	rownames(tabl) = names(logReg$coefficients)
	colnames(tabl) = c("Coeff", "SE", "z", "p", "OR", "CIlo", "CIup", " ")

	if	(tex)
		zTxTbl(tabl, ...)
	else	{
		cat("\nLogistic regression:  ")
		print(formula)
		cat("\n")
		print(tabl, digits=3)
		}

	return(list(table=tabl, model=logReg))
	}
