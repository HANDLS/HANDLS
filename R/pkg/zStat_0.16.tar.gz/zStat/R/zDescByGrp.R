zDescByGrp = function(dat, byGrp, varBeg, varEnd, varNames=names(dat)) {

	if	(!missing(varBeg) & !missing(varEnd))
		varNames = zNamesRange(dat, varBeg, varEnd)
	else	varNames = zNamesRange(dat, varNames[1], varNames[length(varNames)])

	n = 0
	varRange = vector(mode='integer')

	for	(j in varNames) {

		if	(is.numeric(dat[,j])) {
			n = n + 1
			varRange = c(varRange, j)
			}

		}
	mtx = t(tapply(dat[,varRange], dat[,byGrp], zByFUN))
	colnames(mtx) = zQ(N,Mean,SD,Min,Max)
	round(mtx, digits=2)
	}
