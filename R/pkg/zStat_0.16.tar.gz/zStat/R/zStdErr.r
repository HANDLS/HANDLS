zStdErr <- function(x) {

	sqrt(var(x, na.rm=TRUE) / length(na.omit(x)))
	}
