zPlotMeanBarCI <- function(dat, byGrp, ylabel=NULL, ylimits=NULL, colors=NULL, legendLoc='topright') {

	agg.m <- aggregate(dat, by=byGrp, FUN=mean, na.rm=T)
	agg.s <- aggregate(dat, by=byGrp, FUN=zStdErr)

	nrow <- nlevels(byGrp[[1]])
	ncol <- nlevels(byGrp[[2]])

	mtx.m <- matrix(data=agg.m$x, nrow=nrow, ncol=ncol)
	mtx.s <- matrix(data=agg.s$x, nrow=nrow, ncol=ncol)

	rownames(mtx.m) <- levels(byGrp[[1]])
	colnames(mtx.m) <- levels(byGrp[[2]])

	if (is.null(ylimits)) ylimits <- c(0, max(mtx.m)+max(mtx.s))

	plt = barplot(mtx.m, beside=TRUE, ylab=ylabel, ylim=ylimits, col=colors, axis.lty=1)

	len <- 1 / (max(plt) - min(plt))

	for	(i in 1:nrow) {
	for	(j in 1:ncol) {
		arrows(plt[i,j], mtx.m[i,j]+mtx.s[i,j], plt[i,j], mtx.m[i,j]-mtx.s[i,j], angle=90, code=3, length=len)
		}}

	legend(legendLoc, levels(byGrp[[1]]), col=colors, fill=colors)
	}
