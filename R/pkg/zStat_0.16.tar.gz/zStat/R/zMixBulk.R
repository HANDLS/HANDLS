zMixBulk = function(dvnames, iform, dat, justAst = FALSE, tex = FALSE, astTranspose=FALSE, ...) {

	library("lme4")
	library("multcomp")

	models = list()

	nReg = 0

	for	(y in dvnames) {
		nReg = nReg + 1
		f = paste(y, "~", iform, sep="")
		eval(parse(text = paste("mod = lmer(", f, ", data = dat, na.action = na.omit)", sep = "")))
		cft = cftest(mod)
		row = data.frame(dum=f)

		for (j in 2:length(cft$test$coefficient)) {

			if	(justAst)
				res = data.frame(zAsterisks(cft$test$pvalue[j]))
				else
				res = data.frame(cft$test$coefficient[j], zAsterisks(cft$test$pvalue[j]))

			rownames(res) = y
			row = cbind(row, res)
			}

		if	(nReg == 1) {
			tbl = row
			}
			else
			tbl = rbind(tbl, row)

		models[nReg] = mod
		}

	n = 1
	tbl.colnames = " "

	for (j in 2:length(cft$test$coefficient)) {
		n = n + 1
		tbl.colnames[n] = names(cft$test$coefficient)[j]

		if	(!justAst) {
			n = n + 1
			tbl.colnames[n] = " "
			}

		}

	colnames(tbl) = tbl.colnames

	tbl[,1] = NULL

	if (astTranspose) tbl <- zTblAstT(tbl)

	if (tex) zTxTbl(tbl, ...)

	names(models) = dvnames

	return(list(mod=models, tbl=tbl))
	}
