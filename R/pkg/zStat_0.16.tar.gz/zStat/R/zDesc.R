zDesc = function(dat, nRound=2) {

	varLabel = data.frame()
	varRange = vector(mode='integer')
	k = 0

	for	(j in 1:ncol(dat)) {

		if	(is.numeric(dat[,j])) {
			k = k + 1
			varLabel[k,1] = label(dat)[j]
			varRange = c(varRange, j)
			}

		}

	mtx = t(sapply(dat[,varRange], zByFUN))
	colnames(mtx) = zQ(N,Mean,SD,Min,Max)
	mtx = round(mtx, digits=nRound)
	mtx = cbind(mtx, varLabel)
	names(mtx)[ncol(mtx)] = ''
	format(mtx, justify='left')
	}
