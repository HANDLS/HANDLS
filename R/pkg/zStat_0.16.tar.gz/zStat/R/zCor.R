zCor <- function(x, y) {

	z.x <- as.matrix(x)

	if	(missing(y)) {
		sym <- TRUE
		z.y <- z.x
		}
	else	{
		sym <- FALSE
		z.y <- as.matrix(y)
		}

	ns  <- as.integer(nrow(z.x))
	nvx <- as.integer(ncol(z.x))
	nvy <- as.integer(ncol(z.y))

	if (ns != nrow(z.y)) stop ("zStatCor: x and y must have same number of rows")

	storage.mode(z.x) <- "double"
	storage.mode(z.y) <- "double"

	mtx <- .C("zCor", as.double(z.x), as.double(z.y), r=double(nvx*nvy), n=double(nvx*nvy), ns, nvx, nvy, NAOK=TRUE, PACKAGE="zStat")

	xNames = colnames(z.x)
	yNames = colnames(z.y)

	r = matrix(mtx$r, nrow=nvx, ncol=nvy)
	n = matrix(mtx$n, nrow=nvx, ncol=nvy)

	dimnames(r) = list(xNames, yNames)
	dimnames(n) = list(xNames, yNames)

	structure(list(r=r, n=n), class="zCor")
	}

print.zCor <- function(lst, ...) {

	nrow <- nrow(lst$r)
	ncol <- ncol(lst$r)

	mtx <- matrix(nrow=nrow, ncol=ncol)
	p   <- matrix(2*(1-pt(abs(lst$r)*sqrt(lst$n-2)/sqrt(1-lst$r*lst$r), lst$n-2)), nrow=nrow, ncol=ncol)

	dimnames(mtx) <- list(rownames(lst$r), colnames(lst$r))

	for	(i in 1:nrow) {
	for	(j in 1:ncol) {

		if (i==j)	mtx[i,j] <- paste0(formatC(lst$r[i,j], digits=2, format='f', width=5))
		else		mtx[i,j] <- paste0(formatC(lst$r[i,j], digits=2, format='f', width=5), zAsterisks(p[i,j]))
# 		else		mtx[i,j] <- paste(formatC(lst$r[i,j], digits=2, format='f', width=5), zAsterisks(p[i,j]), sep='')
		}}

	print(mtx, quote=FALSE)

	if	(all(lst$n == lst$n[1,1])) cat("\nn = ", lst$n[1,1], "\n\n")
	else	{
		cat("\nn\n")
		print(lst$n)
		}

# 	return(mtx)
#	cat("\np\n")

#	p[abs(h)==1] <- 0
#  diag(P) <- NA
#	dimnames(p) <- list(rownames(lst$r), colnames(lst$r))

#	p <- format(round(p, 4))
#	print(p, quote=FALSE)

#	print(round(lst$r, 2))
	}

summary.zCor <- function(lst, ...) {

	nrow <- nrow(lst$r)
	ncol <- ncol(lst$r)

	mtx <- matrix(nrow=nrow, ncol=ncol)
	p   <- matrix(2*(1-pt(abs(lst$r)*sqrt(lst$n-2)/sqrt(1-lst$r*lst$r), lst$n-2)), nrow=nrow, ncol=ncol)

	dimnames(mtx) <- list(rownames(lst$r), colnames(lst$r))

	for	(i in 1:nrow) {
	for	(j in 1:ncol) {
		if (i==j)	mtx[i,j] <- paste0(formatC(lst$r[i,j], digits=2, format='f', width=5))
		else		mtx[i,j] <- paste0(formatC(lst$r[i,j], digits=2, format='f', width=5), zAsterisks(p[i,j]))
		}}

	print(mtx, quote=FALSE)

	if	(all(lst$n == lst$n[1,1])) cat("\nn = ", lst$n[1,1], "\n\n")
	else	{
		cat("\nn\n")
		print(lst$n)
		}

	invisible(mtx)
	}
