#include <math.h>
#include <R.h>
#include <Rmath.h>

#define ndx(i,j,m) (j * m + i)			/* j*mi+i for array(mi,mj)*/
#define valNum(a,b) (R_FINITE(a) && R_FINITE(b))

void zCor(double *x, double *y, double *xy, double *pn, int *ns, int *nvx, int *nvy) {

	double sx, sy, xx, yy;			/* x(ns,nvx), y(nx,nvy), xy(nvx,nvy) */
	int i, ix, j, jx, n, pw, px, py;

	for	(i=0; i<*nvx; i++) {
	for	(j=0; j<*nvy; j++) {
		pw = ndx(i, j, *nvx);
		sx = 0;
		sy = 0;
		xx = 0;
		yy = 0;
		pn[pw] = 0;
		xy[pw] = 0;

		for	(n=0; n<*ns; n++) {
			px = ndx(n, i, *ns);
			py = ndx(n, j, *ns);

			if	(valNum(x[px], y[py])) {
				sx      = sx    + x[px];
				sy      = sy    + y[py];
				xx      = xx    + x[px] * x[px];
				yy      = yy    + y[py] * y[py];
				pn[pw] = pn[pw] + 1.0;
				xy[pw] = xy[pw] + x[px] * y[py];
				}
			}

		if	(pn[pw]>2.0) {
			xx = xx - sx * sx / pn[pw];
			yy = yy - sy * sy / pn[pw];

			if	(xx>0.0 && yy>0.0)
				xy[pw] = (xy[pw] - sx * sy / pn[pw]) / sqrt(xx * yy);
				else
				xy[pw] = NA_REAL;
			}
			else
			xy[pw] = NA_REAL;

		}
		}

	}
